<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Login</h1>
<?php
if(isset($_REQUEST['msg'])){
	print"<div style='color:#f00;'> $_REQUEST[msg]</div>";
}

?>
<form action="login-check.php" method="post">
	
Email: <input type="text" name="em" placeholder="Enter your email"><br>
Password: <input type="Password" name="pwd" placeholder="Enter your Password"><br>
<input type="submit" value="Login">

</form>

</body>
</html>