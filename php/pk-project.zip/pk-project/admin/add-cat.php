<form action="adding-cat.php" method="post">

Name: <input type="text" name="nm" ><br>
isActive: 
<input type="radio" name="isActive" value="y" checked="checked"> Yes 
<input type="radio" name="isActive" value="n"> No
<br>
<input type="submit" value="Add"> 
</form>